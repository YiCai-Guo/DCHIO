from chio_my import MY_CHIO
import scipy
from FJSP_env import Flexible
import time
import codecs
import csv
import os


def result_write_csv(result_name, res):  # result_name为写入CSV文件的路径及名称，res为需要写入数据列表
    file_csv = codecs.open(result_name, 'w+', 'utf-8')  # 追加
    writer = csv.writer(file_csv, delimiter=' ', quotechar=' ', quoting=csv.QUOTE_MINIMAL)
    for data in res:
        writer.writerow(data)
    print("保存csv文件成功，处理结束")


# for i in [6, 7, 10, 2, 4, 5, 1, 3, 9, 8]:
for i in range(1, 11):
    filename = '.\\DataSet\\Mk' + str(i).zfill(2) + '.txt'
    # filename = '.\\DataSet\\Mk10.txt'

    name = str.split(str.split(filename, '\\')[-1], '.')[0]
    # when = time.asctime()[4:16].replace(':', '-')
    when = time.asctime()[4:16]
    date = when[0:6]
    current = when[7:12].replace(':', '-')
    with open('.\\' + date + '@' + current + '_' + name + '.txt', 'a') as f:
        env = Flexible(filename, name)
        """
        brr随机交流，2也随机
        order选择，p2更新，create_solution，综合性vns,0.1概率换机器，
        全算例测试mutation 0.05+0.05,
        正交实验
        """
        epoch = 500
        pop_size = 100
        brr = 0.98
        max_age = 30

        f.write('**************start time*************: ' + time.asctime() + '\n')
        f.write(f'epoch: {epoch}, pop_size: {pop_size}, brr: {brr}, max_age: {max_age}'+'\n')
        s = 0
        for repeat in range(10):
            model = MY_CHIO(env, epoch, pop_size, brr, max_age)
            # model = BaseCHIO(epoch, pop_size, brr, max_age)
            f1, f2, pareto_front, num = model.solve()  # model 里继承了父类 optimizer 中的 solve 方法
            # model.draw_convergence(repeat, name, date, current)
            # env.draw_gantt(best_position, repeat, name, date, current)
            # f.write(current + ' '+str(repeat) + " "+str(best_fitness) + ' '+str(converge_epoch)+'\n')
            # s += best_fitness
            # z += converge_epoch

            # 保存最优个体
            result_path = date + '@' + current + '_pareto_' + '@' + name
            if not os.path.exists(result_path):
                os.mkdir(result_path)
            path_name = "./" + result_path + '/' + name + "第" + str(repeat) + "次重复的Pareto解个体位置目标向量.csv"
            result_write_csv(path_name, pareto_front)

            s += num
            f.write(current + ' ' + str(repeat) + " " + str(num) + '\n')
            model.draw_pareto_front(repeat, name, date, current, f1, f2)
        average_num = s/(repeat+1)
        f.write(current + ' '+"Average " + '%d' % average_num + '\n')
        f.write('finish time: '+time.asctime()+'\n'*2)

