import random
from copy import deepcopy
import numpy as np
import time
import matplotlib.pyplot as plt
from matplotlib.pylab import mpl
import os

plt.rcParams['font.sans-serif'] = ['STSong']
mpl.rcParams['font.sans-serif'] = ['SimHei']  # 添加这条可以让图形显示中文


class MY_CHIO:
    def __init__(self, fjsp, epoch=10000, pop_size=100, brr=0.15, max_age=10, **kwargs):
        """
        Args:
            epoch (int): maximum number of iterations, default = 10000
            pop_size (int): number of population size, default = 100
            brr (float): Basic reproduction rate, default=0.15
            max_age (int): Maximum infected cases age, default=10
        """
        # super().__init__(**kwargs)  # super() 用来调用父类(基类)的方法  # 这里kwargs没有值，用**拆解之后依然为空，所以就是没有传入任何参数
        self.epoch = epoch
        self.pop_size = pop_size
        self.brr = brr
        self.max_age = max_age
        self.env = fjsp
        self.one_dims = len(fjsp.job_repeat)
        self.pop = []
        self.FIT_ID = 1  # 一个个体的适应度值的位置索引
        self.FIT_ID_2 = 2  # 第二个调度目标的索引
        self.POS_ID = 0  # 一个个体的位置向量索引
        self.list_global_best = []
        self.last_best = float('inf')
        self.first_best_epoch = float('-inf')
        self.good_pop = []

    def solve(self):
        """
        主函数循环体，控制算法总流程
        :return:
        f1 (list): pareto前沿中个体对应的f1函数的值
        f1 (list): pareto前沿中个体对应的f2函数的值
        pareto_front (list): pareto前沿中的个体，单个元素为： [array(位置), 函数1的值， 函数2的值]
        max(len(set(f1)), len(set(f2))) (int): pareto前沿中的点的数目
        """
        self.pop = self.create_population()
        self.initialize_variables()
        for gen in range(0, self.epoch):
            time_epoch = time.perf_counter()
            self.evolve(gen)
            front1, front2, _ = self.global_best_record(self.pop, gen)
            time_epoch = time.perf_counter() - time_epoch
            # print(f"DataSet: {self.env.dataset_name}, Epoch: {gen}, Runtime: {time_epoch:.5f} seconds\n"
            #       f"function 1:{min(front1)}\n"
            #       f"function 2:{min(front2)}")
            print(f"DataSet: {self.env.dataset_name}, Epoch: {gen}, Runtime: {time_epoch:.5f} seconds "
                  f"function1: {min(front1)}, function2: {min(front2)}", end="   ")
            print(f"ParetoFront的数量: {len(front1)}", end="  ")
            num = max(len(set(front1)), len(set(front2)))  # pareto front中点的数目
            print(f"去重后数目： {num}")

            # if gen % 10 == 0:
            #     v1 = [temp[self.FIT_ID] for temp in self.pop]
            #     v2 = [temp[self.FIT_ID_2] for temp in self.pop]
            #     self.draw_pop(v1, v2)

        # print(self.pop)
        _, _, last_front = self.global_best_record(self.pop, gen)

        f1, f2, pareto_front = self.global_best_record(self.pop+last_front, gen)
        return f1, f2, pareto_front, max(len(set(f1)), len(set(f2)))

    def global_best_record(self, pop, it, save=True):
        """
        只保留最外层的Pareto解
        Args:
            pop (list): The population of pop_size individuals
            save (bool): True if you want to add new current/global best to history,
                        False if you just want to update current/global best
            it (int): 当前代数，用于记录哪个回合收敛
        Returns:
            front1 (list): 最外层pareto front 对应的 函数1的值
            front2 (list): 最外层pareto front 对应的 函数2的值
           pareto (list): 最外层pareto front 对应的 个体向量

        """
        v1 = [temp[self.FIT_ID] for temp in pop]
        v2 = [temp[self.FIT_ID_2] for temp in pop]
        grade = self.fast_non_dominated_sort(v1, v2)[0]
        front1 = [v1[x] for x in grade]
        front2 = [v2[y] for y in grade]
        pareto = [pop[i] for i in grade]
        return front1, front2, pareto

    def order_cross_1(self, p1, p2, r1):
        """
        POX交叉操作：
        对p1执行r1选择，即r1集合内工件的对应的工件加工顺序保持不变，然后产生c1
        Args：
            p1： np.array类型，位置向量，两段式编码的第一段，长度为 self.one_dims
            p2： np.array类型，位置向量，两段式编码的第一段，长度为 self.one_dims
            r1: 工件集合，全部工件集合的半集，与r2构成工件全集
        Return：
            c1，c2：np.array类型，交叉后的order段的编码，长度为 self.one_dims
        """
        c1, c2 = [], []
        j = 0
        for i in range(self.one_dims):
            if p1[i] in r1:
                c1.append(p1[i])
            else:
                while p2[j] in r1:
                    c2.append(p2[j])
                    j += 1
                c2.append(p1[i])
                c1.append(p2[j])
                j += 1
        while j != self.one_dims:
            c2.append(p2[j])
            j += 1
        return np.array(c1), np.array(c2)

    def code_separate(self, code):
        """
        将两段式编码code转化为：job_sequence（前半段编码）、机器选择列表
        Args：
            code：np.array类型，两段式编码，前半段为job排序，后半段为机器选择结果，np.array类型，长度为 2*self.one_dims
        Returns:
            job_sequence：np.array类型，code的前半段编码，长度为 self.one_dims
            machine_separate：list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器选择结果],[job2的机器选择结果],……]
            machine_sp：list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器加工速度],[job2的机器加工速度],……]
        """
        machine_separate = []
        machine_sp = []
        for i in range(self.env.job_num):
            machine_separate.append([])
            machine_sp.append([])
        for j in range(self.one_dims):
            job = code[j] - 1
            machine_separate[job].append(code[self.one_dims + j])
            machine_sp[job].append(code[2*self.one_dims + j])
        job_sequence = deepcopy(code[0:self.one_dims])
        return job_sequence, machine_separate, machine_sp

    def code_mix(self, job_part, machine_list, speed_list):
        """
        将两部分结果混合，构成两段式编码
        Args：
            job_part: np.array类型，长度 self.one_dims
            machine_list: list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器选择结果],[job2的机器选择结果],……]
        Returns:
            code: np.array类型，两段式编码，长度为 2*self.one_dims
        """
        op_record = np.zeros(self.env.job_num, dtype=int)  # 用于记录已经加工到该工件的第几个工序
        machine_record = []
        speed_record = []
        for i in range(self.one_dims):
            job = job_part[i] - 1
            op = op_record[job]
            machine_record.append(machine_list[job][op])
            speed_record.append(speed_list[job][op])
            op_record[job] += 1
        machine_part = np.array(machine_record)
        speed_part = np.array(speed_record)
        code = np.hstack((job_part, machine_part, speed_part))
        return code

    def machine_mpx(self, machine_1, machine_2):
        """
        将两机器选择结果，按照50%概率执行交叉操作
        Args：
            machine_list_1: list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器选择结果],[job2的机器选择结果],……]
            machine_list_2: list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器选择结果],[job2的机器选择结果],……]
        Returns:
            machine_list_1: list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器选择结果],[job2的机器选择结果],……]
            machine_list_2: list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器选择结果],[job2的机器选择结果],……]
        """
        for j in range(self.env.job_num):
            op_n = len(machine_1[j])
            for k in range(op_n):
                if machine_1[j][k] != machine_2[j][k]:
                    if np.random.randint(0, 2):
                        machine_1[j][k], machine_2[j][k] = machine_2[j][k], machine_1[j][k]
        return machine_1, machine_2

    def evolve(self, epoch):
        """
        The main operations (equations) of algorithm.

        Args:
            epoch (int): The current iteration
        """
        new_pop = deepcopy(self.pop)  # 在原有种群上，用于补充新产生的个体
        new_type = deepcopy(self.immunity_type_list)
        new_age = deepcopy(self.age_list)
        r = {i+1 for i in range(self.env.job_num)}  # 工序编号全集 从1开始计数编号
        for i in range(0, self.pop_size):
            temp = self.pop[i]
            temp_type = self.immunity_type_list[i]
            j1, m1, s1 = self.code_separate(temp[self.POS_ID])
            if np.random.uniform() <= 0.8:
                if np.random.uniform() <= self.brr:
                    rand = self.immunity_type_list[i]
                    # if rand < (1.0 / 3) * self.brr:
                    if rand == 1:
                        idx_candidates = np.where(self.immunity_type_list == 1)  # Infected list
                        idx_selected = np.random.choice(idx_candidates[0])
                        # 轮盘赌法
                        # fit_list = np.array([self.pop[item][self.FIT_ID] for item in idx_candidates[0]])
                        # s = fit_list.sum()
                        # idx_selected = np.random.choice(idx_candidates[0], p=fit_list / s)
                        # 头狼引领法
                        # the_min = np.where(fit_list == min(fit_list))
                        # idx_selected = idx_candidates[0][np.random.choice(the_min[0])]  # Found the index of min
                        r1 = set(random.sample(r, int(self.env.job_num / 2)))  # 工序编号的半集1
                        # is_corona_list[i] = True
                    elif rand == 0:
                        idx_candidates = np.where(self.immunity_type_list == 0)  # Susceptible list
                        idx_selected = np.random.choice(idx_candidates[0])
                        # 轮盘赌法
                        # fit_list = np.array([self.pop[item][self.FIT_ID] for item in idx_candidates[0]])
                        # s = fit_list.sum()
                        # idx_selected = np.random.choice(idx_candidates[0], p=fit_list / s)
                        # 头狼引领法
                        # the_min = np.where(fit_list == min(fit_list))
                        # idx_selected = idx_candidates[0][np.random.choice(the_min[0])]   # Found the index of min
                        r1 = set(random.sample(r, int(self.env.job_num / 3)))
                    else:  # rand == 2
                        idx_candidates = np.where(self.immunity_type_list == 2)  # Immunity list
                        idx_selected = np.random.choice(idx_candidates[0])
                        # 轮盘赌法
                        # fit_list = np.array([self.pop[item][self.FIT_ID] for item in idx_candidates[0]])
                        # s = fit_list.sum()
                        # idx_selected = np.random.choice(idx_candidates[0], p=fit_list / s)
                        # 头狼引领法
                        # the_min = np.where(fit_list == min(fit_list))
                        # idx_selected = idx_candidates[0][np.random.choice(the_min[0])]  # # Found the index of min
                        r1 = set(random.sample(r, int(self.env.job_num / 4)))
                else:
                    pop_num = {k for k in range(len(self.pop))} - {i}
                    idx_selected = np.random.choice(list(pop_num))
                    # idx_selected = self.choose_approximate_fitness(temp[self.FIT_ID])
                    size = np.random.randint(2, self.env.job_num-1)
                    r1 = set(random.sample(r, size))  # 工序编号的半集1

                p2 = self.pop[idx_selected]
                j2, m2, s2 = self.code_separate(p2[self.POS_ID])

                # order 交叉操作
                j1_1, j2_1 = self.order_cross_1(j1, j2, r1)
                c1_1, c2_1 = self.code_mix(j1_1, m1, s1), self.code_mix(j2_1, m2, s2)
                temp = self.choose_min(temp, c1_1)
                temp = self.choose_min(temp, c2_1)
                # machine 交叉操作
                m1_1, m2_1 = self.machine_mpx(m1, m2)
                c1_2, c2_2 = self.code_mix(j1_1, m1_1, s1), self.code_mix(j2_1, m2_1, s2)
                temp = self.choose_min(temp, c1_2)
                temp = self.choose_min(temp, c2_2)
                # speed 交叉操作
                s1_1, s2_1 = self.machine_mpx(s1, s2)
                if len(set(temp[self.POS_ID][2*self.one_dims:])) == 1:
                    s1_1 = s1
                c1_3, c2_3 = self.code_mix(j1_1, m1_1, s1_1), self.code_mix(j2_1, m2_1, s2_1)
                temp = self.choose_min(temp, c1_3)
                temp = self.choose_min(temp, c2_3)

                # c1 = self.code_mix(j1_1, m1_1, s1_1)
                # c2 = self.code_mix(j2_1, m2_1, s2_1)
                # f1, _, _ = self.env.active_schedule(c1)
                # f2 = self.env.energy_cost()
                # f1_1, _, _ = self.env.active_schedule(c2)
                # f2_1 = self.env.energy_cost()
                # if f1 >= f1_1 and f2 >= f2_1:
                #     temp = [c2, f1_1, f2_1]
                # else:
                #     temp = [c1, f1, f2]
                # temp = [c1, f1, f2]  # p1单向学习p2

            if np.random.uniform() < 0.3:
                jp, mp, sp = self.code_separate(temp[self.POS_ID])
                temp1 = self.variation_insert(jp, 0.05 + 0.05 * epoch/self.epoch)   # 参数设置为0.05+0.05比0.1+0.2好很多
                temp2 = self.variation_machine(mp, 0.05 + 0.05 * epoch/self.epoch)
                temp3 = self.variation_speed(sp, 0.05 + 0.05 * epoch/self.epoch)
                te = self.code_mix(temp1, temp2, temp3)
                fun1, _, _ = self.env.active_schedule(te)
                fun2 = self.env.energy_cost()
                if fun1 < temp[self.FIT_ID] or fun2 < temp[self.FIT_ID_2]:
                    temp = [te, fun1, fun2]
                # temp = [te, fun1, fun2]

            # Step 3.5: variable_neighborhood_search
            temp_vns = self.variable_neighborhood_search(temp[0])
            t, _, _ = self.env.active_schedule(temp_vns)
            cost2 = self.env.energy_cost()
            if t <= temp[1]:
                temp = [temp_vns, t, cost2]
            # temp = [temp_vns, t, cost2]

            # 年龄增长
            if self.pop[i][self.FIT_ID] > temp[self.FIT_ID] or self.pop[i][self.FIT_ID_2] > temp[self.FIT_ID_2]:
                self.age_list[i] = 0
            else:
                self.age_list[i] += 1

            new_pop.append(temp)
            new_type = np.append(new_type, temp_type)
            new_age = np.append(new_age, 0)

        # Step 4: ***********针对new_pop执行非支配排序，产生新的半个种群*************
        val1 = [one[self.FIT_ID] for one in new_pop]
        val2 = [one[self.FIT_ID_2] for one in new_pop]
        front_layers = self.fast_non_dominated_sort(val1, val2)
        for i in range(len(front_layers)):
            sorted_layer = self.crowding_distance_sort(val1, val2, front_layers[i])
            front_layers[i] = deepcopy(sorted_layer)
        half_index = []
        for i in range(len(front_layers)):
            for j in front_layers[i]:
                half_index.append(j)
                if len(half_index) == self.pop_size:
                    break
            if len(half_index) == self.pop_size:
                break
        for i in range(self.pop_size):
            id = half_index[i]
            self.pop[i] = new_pop[id]
            self.immunity_type_list[i] = new_type[id]
            self.age_list[i] = new_age[id]

        # Step 5: Fatality condition
        for h in range(0, self.pop_size):
            if self.age_list[h] >= self.max_age:
                # self.pop[i] = self.create_offspring()
                self.good_pop.append(self.pop[h])
                self.pop[h] = self.create_solution()
                self.immunity_type_list[h] = self.immunity_type_list[h]
                self.age_list[h] = 0

        # 加一个环节，清理重复元素
        self.pop, self.age_list = self.clear_repeat(self.pop, self.age_list)

    @staticmethod
    def fast_non_dominated_sort(values1, values2):
        """
        快速支配排序算法
        :param values1: list，一维的，长度 pop_size， fun1 计算得到的
        :param values2: list，一维的，长度 pop_size， fun2 计算得到的
        :return: front，二维列表，元素为位置索引，分层（等级）情况，长度不固定
                        [ [],
                          [],
                             ]
        """
        front = [[]]  # 记录分层情况
        S = [[] for i in range(0, len(values1))]  # 记录每个位置个体所支配的解
        n = [0 for i in range(0, len(values1))]  # 存储种群中支配本个体的个体数目
        rank = [0 for i in range(0, len(values1))]  # rank记录最终的等级，n所记录的等级会在逐步分层中变化

        for p in range(0, len(values1)):  # p为索引，遍历每个values[p]所支配的解的索引，并存储在S[p]中
            # S[p] = []  # 重复了感觉
            # n[p] = 0  # 重复了感觉
            for q in range(0, len(values1)):
                if (values1[p] < values1[q] and values2[p] < values2[q]) or (
                        values1[p] <= values1[q] and values2[p] < values2[q]) or (
                        values1[p] < values1[q] and values2[p] <= values2[q]):  # p位置对应的解比q位置对应的解好，p支配了q
                    if q not in S[p]:
                        S[p].append(q)
                elif (values1[q] < values1[p] and values2[q] < values2[p]) or (
                        values1[q] <= values1[p] and values2[q] < values2[p]) or (
                        values1[q] < values1[p] and values2[q] <= values2[p]):  # q位置对应的解比p位置对应的解好
                    n[p] = n[p] + 1  # p位置的解排序等级+1，被一个解支配了
            if n[p] == 0:  # 构造pareto前沿，为while循环开路
                rank[p] = 0
                if p not in front[0]:
                    front[0].append(p)
        #  开始构造pareto分层情况
        i = 0
        while front[i] != []:
            front_next = []
            for p in front[i]:  # p在pareto前沿上，
                for q in S[p]:  # q为被values[p]支配的解
                    n[q] = n[q] - 1
                    # 剪完之后，n[q] = 0说明value[q]在下一层的前沿中
                    if n[q] == 0:
                        rank[q] = i + 1  # 设置value[q]的pareto等级（也就是层数，从0开始计数）
                        if q not in front_next:
                            front_next.append(q)
            i = i + 1
            front.append(front_next)
        del front[len(front) - 1]  # 对于种群的最后一层，非空，进入while，但for中一个元素都不会添加，所以front最后会有一个空的list
        return front

    @staticmethod
    def crowding_distance_sort(values1, values2, layer):
        """
        计算每一层的拥挤距离。拥挤距离：左右两个点的差值，横纵坐标的差值相加

        :param values1: list，一维，种群个体对应的fun1值
        :param values2: list，一维，种群个体对应的fun2值
        :param layer: list，元素为位置索引，pareto分层情况中的一层
        :return layers_sorted_dis: 根据拥挤度距离排序后的这个layer，拥挤距离大的排在前面
        """
        sorted1 = sorted(layer, key=lambda x: values1[x])
        distance = [0 for i in range(0, len(layer))]

        # 第一个和最后一个拥挤度最大，边缘的两个点
        distance[0] = 4444444444444444
        distance[len(layer) - 1] = 4444444444444444
        for k in range(1, len(layer) - 1):  # 去除了第一个元素和最后一个元素len()-1,此二者距离无穷     用max和min进行全局的归一化
            distance[k] = distance[k] + (values1[sorted1[k + 1]] - values1[sorted1[k - 1]]) / (
                        max(values1) - min(values1))
        for k in range(1, len(layer) - 1):
            distance[k] = distance[k] + (values2[sorted1[k + 1]] - values2[sorted1[k - 1]]) / (
                        max(values2) - min(values2))
        layer_sorted_dis = sorted(layer, key=lambda x: distance[sorted1.index(x)], reverse=True)
        return layer_sorted_dis

    def choose_approximate_fitness(self, f):
        """
        死亡个体的替代问题，随机选取，近期一定比例（proportion）全局最优解替代
        Args:
            f: float类型，适应度值
        Returns:
            idx_select: int类型，self.pop种群被选中个体的位置下标
        """
        fit_list = [item[self.FIT_ID] for item in self.pop]
        fit_sort = sorted(fit_list)
        b = fit_sort.index(f)
        if b == 0:
            idx_select = np.random.choice([i for i in range(int(0.1*len(self.pop))) ])
        else:
            res = fit_sort[b - 1]
            idx_candidates = np.where(np.array(fit_list) == res)  # Susceptible list
            idx_select = np.random.choice(idx_candidates[0])
        return idx_select

    def create_supply(self, proportion=0):  # 后 proportion 的 self.good_pop 才有资格参与产生子代
        """
        死亡个体的替代问题，随机选取，近期一定比例（proportion）全局最优解替代
        Args:
            proportion: float类型，self.list_global_best 后半部分的比例的个体替代死亡个体
        Returns:
            [code: np.array类型, target: float类型，makespan]
        """
        parents = len(self.good_pop)
        which = np.random.choice([i for i in range(int(proportion * parents), parents)])
        last_best = self.good_pop[which][self.POS_ID]
        sequence_p, machine_p, speed_p = self.code_separate(last_best)
        s_p = self.variation_reverse(sequence_p)
        m_p = self.variation_machine(machine_p)
        code = self.code_mix(s_p, m_p, speed_p)
        target, _, _ = self.env.active_schedule(code)
        cost = self.env.energy_cost()
        return [code, target, cost]

    def variation_reverse(self, order, vc=0.5):
        """
        逆序变异，近期一定比例（proportion）全局最优解替代
        Args:
            order: np.array类型，self.list_global_best 后半部分的比例的个体替代死亡个体
            vc: float类型，order的 vc 比例长度执行逆序操作
        Returns:
            order_op: np.array类型
        """
        order_op = deepcopy(order)
        one = np.random.randint(0, self.one_dims)
        if one+int(self.one_dims*vc) < self.one_dims:
            end = one+int(self.one_dims*vc)
            while end != one and one < end:
                order_op[end], order_op[one] = order_op[one], order_op[end]
                end -= 1
                one += 1
            return order_op
        elif one-int(self.one_dims*vc) >= 0:
            start = one-int(self.one_dims*vc)
            while start != one and start < one:
                order_op[start], order_op[one] = order_op[one], order_op[start]
                start += 1
                one -= 1
            return order_op
        else:
            return order_op

    def variation_insert(self, order, vc=0.5):
        """
        工序插入变异，近期一定比例（proportion）全局最优解替代
        Args:
            order: np.array类型，长度为self.one_dims
            vc: float类型，order的 vc 比例个位点执行向前插入变异操作
        Returns:
            order_op: np.array类型，长度为self.one_dims
        """
        order_op = deepcopy(order)
        choices = [i for i in range(self.one_dims)]
        select = np.random.choice(choices, int(self.one_dims*vc))
        for i in select:
            search = i
            while order_op[search] == order_op[i] and search != 0:
                search -= 1
            temp = order_op[i]
            order_op = np.delete(order_op, i)
            order_op = np.insert(order_op, search, temp)
        return order_op

    def variation_machine(self, m1, vc=0.5, critical_machine=-1):
        """
        机器变异，按照 vc 概率去参加变异
        Args:
            m1: list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器选择结果],[job2的机器选择结果],……]
            vc: 变异的概率
            critical_machine: 本来打算传入关键机器，目前无作用
        Returns:
            m1: list类型，二维，形状为（工件数，该工件的工序数），[[job1的机器选择结果],[job2的机器选择结果],……]
        """
        for i in range(len(m1)):
            for j in range(len(m1[i])):
                if np.random.choice([0, 1], p=[1-vc, vc]):
                    m1[i][j] = np.random.choice(self.env.machine_sign[i][j])
                    if critical_machine >= 0:
                        if m1[i][j] == critical_machine:
                            idx = np.argmin(self.env.machine_sign[i][j])
                            m1[i][j] = self.env.machine_sign[i][j][idx]
        return m1

    @staticmethod
    def variation_speed(speed, vc=0.5):
        temp = deepcopy(speed)
        for i in range(len(speed)):
            for j in range(len(speed[i])):
                if np.random.uniform() < vc:
                    temp[i][j] = random.randint(0, 2)
        return temp

    def variable_neighborhood_search(self, code):
        """
        逆序变异，近期一定比例（proportion）全局最优解替代
        Args:
            code: np.array类型，长度 self.one_dims * 2
        Returns:
            temp: np.array类型，长度 self.one_dims * 2
        """
        temp = deepcopy(code)
        makespan, last_machine_list, machine_record = self.env.active_schedule(code)
        use_ratio = np.zeros(self.env.machine_num)
        for i in range(self.env.machine_num):
            count = 0
            for j in range(len(machine_record[i])):
                process = machine_record[i][j][2][1] - machine_record[i][j][2][0]
                count += process
            use_ratio[i] = count/makespan

        op_count = np.zeros(self.env.job_num, dtype=int)
        for i in range(self.one_dims):
            job = code[i] - 1
            op = op_count[job]
            machine = code[self.one_dims+i]
            if machine not in last_machine_list:
                op_count[job] += 1
                continue
            else:
                if np.random.choice([0, 1], p=[0.9, 0.1]):
                    optional_m_list = self.env.machine_sign[job][op]
                    optional_m_t = self.env.machine_time[job][op]
                    use_ratio_list = [use_ratio[i-1] for i in optional_m_list]
                    min_ratio_id = use_ratio_list.index(min(use_ratio_list))
                    min_time_id = optional_m_t.index(min(optional_m_t))
                    if machine == optional_m_list[min_time_id]:
                        temp[self.one_dims+i] = optional_m_list[min_ratio_id]
                    elif machine == optional_m_list[min_ratio_id]:
                        temp[self.one_dims+i] = optional_m_list[min_time_id]
                    else:
                        if np.random.randint(2):
                            temp[self.one_dims + i] = optional_m_list[min_ratio_id]
                        else:
                            temp[self.one_dims + i] = optional_m_list[min_time_id]
                op_count[job] += 1
        return temp

    def choose_min(self, code1, code2):
        if len(code1) != 3:
            t1, _, _ = self.env.active_schedule(code1)
            t2 = self.env.energy_cost()
            code1 = [code1, t1, t2]
        if len(code2) != 3:
            m1, _, _ = self.env.active_schedule(code2)
            m2 = self.env.energy_cost()
            code2 = [code2, m1, m2]
        if code2[self.FIT_ID] < code1[self.FIT_ID] or code2[self.FIT_ID_2] < code1[self.FIT_ID_2]:
            return code2
        else:
            return code1

    @staticmethod
    def cross(x, y):
        start = int(len(x)/2)
        for i in range(start, len(x)):
            if np.random.rand() > 0.5:
                x[i], y[i] = y[i], x[i]
        return x, y

    def clear_repeat(self, pop, age_list):
        pop1 = deepcopy(pop)
        age_list1 = deepcopy(age_list)
        f1 = [agent[self.FIT_ID] for agent in pop]
        f2 = [agent[self.FIT_ID_2] for agent in pop]
        a1 = np.array(f1)
        s1 = set(f1)
        for value_f1 in s1:
            where = np.where(a1 == value_f1)[0]
            if where.shape[0] == 1:
                continue
            else:
                one = where[0]
                for i in range(1, where.shape[0]):
                    two = where[i]
                    # if f2[one] == f2[two] and self.compare(pop[one][0], pop[two][0]):
                    if f2[one] == f2[two]:
                        new = self.create_solution()
                        pop1[two] = deepcopy(new)
                        age_list1[two] = 0
        return pop1, age_list1

    @staticmethod
    def compare(x, y):
        for i in range(len(x)):
            if x[i] != y[i]:
                return False
        return True

    def create_population(self, pop_size=None):  # 创建一个种群
        """
        Args:
            pop_size (int): number of solutions

        Returns:
            list: population or list of solutions/agents
        """
        if pop_size is None:
            pop_size = self.pop_size
        pop = []
        for i in range(0, pop_size):
            first = self.create_solution()
            pop.append(first)
        return pop  # pop是一个list，[position（np数组），[fit, obj]]

    def create_solution(self):
        """
        创建一个单独的解（个体）
        To get the position, target wrapper [fitness and obj list]
            + A[self.ID_POS]                  --> Return: position
            + A[self.ID_TAR]                  --> Return: [fitness, [obj1, obj2, ...]]
            + A[self.ID_TAR][self.ID_FIT]     --> Return: fitness
            + A[self.ID_TAR][self.ID_OBJ]     --> Return: [obj1, obj2, ...]
        Returns:
            list: wrapper of solution with format [position, [fitness, [obj1, obj2, ...]]]
            # 创造一个解：[位置向量，优化目标]
        """
        rand_list = random.sample(range(4 * self.one_dims), self.one_dims)
        index = np.array(rand_list).argsort()  # argsort函数返回的是数组值从小到大的索引值
        order = []
        for i in range(self.one_dims):
            order.append(self.env.job_repeat[index[i]])  # 这个时候job编号出现的次数就等于加工的第几道工序了
        machine = []
        machine_speed = []
        # machine_time = []
        operation = np.zeros(self.env.job_num, dtype=int)
        for i in order:
            job = i-1
            op = operation[job]
            choice = random.sample(range(len(self.env.machine_sign[job][op])), 1)
            # print(choice)
            machine.append(self.env.machine_sign[job][op][choice[0]])
            # machine_time.append(self.env.machine_time[job][op][choice[0]])
            operation[job] += 1
            machine_speed.append(random.randint(0, 2))
        # 一定比例的高速个体
        decide = np.random.uniform(0, 1)
        if decide < 0.3:
            machine_speed = [2 for i in order]
        # elif 0.3 < decide < 0.6:
        #     machine_speed = [0 for i in order]
        position = order + machine + machine_speed
        position = np.array(position)
        # target, _, _, _ = self.env.time_count(position)
        target, _, _ = self.env.active_schedule(position)
        cost = self.env.energy_cost()
        return [position, target, cost]  # position是一个np.array

    # # 马训德改写函数
    def initialize_variables(self):
        pop_sort = deepcopy(self.pop)
        fit_list = [agent[self.FIT_ID] for agent in self.pop]
        index = np.array(fit_list).argsort()
        for i in range(len(self.pop)):
            pop_sort[i] = self.pop[index[i]]
        self.pop = deepcopy(pop_sort)
        num = int(self.pop_size / 3)
        type_list = [2, 1, 0] * num + [0] * (self.pop_size - 3 * num)
        # random.shuffle(type_list)
        self.immunity_type_list = np.array(type_list)
        self.age_list = np.zeros(self.pop_size)  # Control the age of each position

    def draw_convergence(self, repeat, name, date, current):
        d = []
        for i in range(self.epoch):
            d.append([i+1, self.list_global_best[i][self.FIT_ID]])
        d = np.array(d).reshape(len(d), 2)
        plt.plot(d[:, 0], d[:, 1])  # 画完工时间随迭代次数的变化
        font1 = {'weight': 'bold', 'size': 17}  # 汉字字体大小，可以修改
        plt.xlabel("迭代次数", font1)
        plt.title(name + "环境下的完工时间变化图", font1)
        plt.ylabel("完工时间", font1)
        folder = date + '@'+current + '_convergence_' + '@' + name
        if not os.path.exists(folder):
            os.mkdir(folder)
        plt.savefig("./" + folder + '/' + name + "第" + str(repeat) + "次重复的convergence.jpg",
                    bbox_inches='tight', dpi=500)
        plt.savefig("./" + folder + '/' + name + "第" + str(repeat) + "次重复的convergence.svg",
                    bbox_inches='tight', dpi=500)
        # plt.ion()
        # plt.show()
        # plt.pause(2)
        plt.close()

    @staticmethod
    def draw_pareto_front(repeat, name, date, current, fun1, fun2):
        font1 = {'weight': 'bold', 'size': 17}  # 汉字字体大小，可以修改
        plt.xlabel('完工时间', font1)
        plt.ylabel('能耗', font1)
        plt.title(name + "环境下的Pareto前沿", font1)
        plt.scatter(fun1, fun2)

        folder = date + '@' + current + '_pareto_' + '@' + name
        if not os.path.exists(folder):
            os.mkdir(folder)
        plt.savefig("./" + folder + '/' + name + "第" + str(repeat) + "次重复的Pareto解.jpg",
                    bbox_inches='tight', dpi=500)
        plt.savefig("./" + folder + '/' + name + "第" + str(repeat) + "次重复的Pareto解.svg",
                    bbox_inches='tight', dpi=500)
        # plt.ion()
        # plt.show()
        # plt.pause(2)
        plt.close()

    @staticmethod
    def draw_pop(fun1, fun2):
        font1 = {'weight': 'bold', 'size': 17}  # 汉字字体大小，可以修改
        plt.xlabel('完工时间', font1)
        plt.ylabel('能耗', font1)
        plt.title("环境下的Pareto前沿", font1)
        plt.scatter(fun1, fun2)
        # plt.ion()
        plt.show()
        # plt.pause(2)
        # plt.close()

